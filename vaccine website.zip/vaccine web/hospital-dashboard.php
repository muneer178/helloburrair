<?php
// Database credentials
$hostname = 'localhost'; // Replace with your hostname
$username = 'root';      // Replace with your username
$password = '';          // Replace with your password
$database = 'user_db';   // Replace with your database name

// Establish a connection to the database
try {
    $pdo = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to receive bookings for a hospital
function receiveBookings($pdo, $hospital_id) {
    // Fetch bookings where status is 'Confirmed' for the hospital
    $sql = "SELECT * FROM bookings WHERE hospital_id = :hospital_id AND status = 'Confirmed'";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':hospital_id', $hospital_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to update vaccination status
function updateVaccinationStatus($pdo, $booking_id, $vaccination_status) {
    // Update vaccination status for a specific booking
    $sql = "UPDATE bookings SET vaccination_status = :vaccination_status WHERE booking_id = :booking_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':vaccination_status', $vaccination_status, PDO::PARAM_STR);
    $stmt->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Handle form submissions or direct page requests

// Example: Check if form submitted to update vaccination status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'], $_POST['vaccination_status'])) {
    $booking_id = $_POST['booking_id'];
    $vaccination_status = $_POST['vaccination_status'];

    if (updateVaccinationStatus($pdo, $booking_id, $vaccination_status)) {
        echo "Vaccination status updated successfully";
    } else {
        echo "Error updating vaccination status";
    }
}

// Example: Display bookings
$hospital_id = 1; // Replace with the actual hospital ID
$bookings = receiveBookings($pdo, $hospital_id);

// Display bookings
foreach ($bookings as $booking) {
    echo "<p>Booking ID: " . $booking['booking_id'] . "</p>";
    echo "<p>User ID: " . $booking['user_id'] . "</p>";
    echo "<p>Appointment Date: " . $booking['appointment_date'] . "</p>";
    
    // Display form to update vaccination status
    echo "<form method='post'>";
    echo "<input type='hidden' name='booking_id' value='" . $booking['booking_id'] . "'>";
    echo "<label>Vaccination Status:</label>";
    echo "<select name='vaccination_status'>";
    echo "<option value='Vaccinated' " . ($booking['vaccination_status'] == 'Vaccinated' ? 'selected' : '') . ">Vaccinated</option>";
    echo "<option value='Not Vaccinated' " . ($booking['vaccination_status'] == 'Not Vaccinated' ? 'selected' : '') . ">Not Vaccinated</option>";
    echo "</select>";
    echo "<input type='submit' value='Update'>";
    echo "</form>";
    
    echo "<hr>";
}
?>
